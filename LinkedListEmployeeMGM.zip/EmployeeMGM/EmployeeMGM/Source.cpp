#include<iostream>
#include<string>
#include<algorithm>
#include<fstream>


using namespace std;
struct Date
{
	int Day;
	int Month;
	int Year;

};
struct Employee
{
	int ID;
	string  FN, LN, SSN;
	Date HireDate;
};
class Node
{
public:
	Employee data;
	Node *nextptr;

};
istream &operator >> (istream &in, Employee *Emp)
{
	cout << "ID: ";
	in >> Emp->ID;
	
	cout << "FirstName: ";
	cin >> Emp->FN;
	
	cout << "LastName: ";
	cin >> Emp->LN;
	
	cout << "Social Security Number: ";
	in >> Emp->SSN;

	cout << "Hired Day: ";
	in >> Emp->HireDate.Day;

	cout << "Hired Month: ";
	in >> Emp->HireDate.Month;

	cout << "Hired Year: ";
	in >> Emp->HireDate.Year;

	return in;

}
ostream &operator <<(ostream &out, Employee&emp)
{
	out << "Employee: " << emp.ID << "," << emp.FN << ","<<emp.LN<<"," << emp.SSN << "," << emp.HireDate.Day << "," << emp.HireDate.Month << "," << emp.HireDate.Year << endl;
	return out;
}
Node* HeadNode(Node *head, Employee *emp)
{
	Node * node = new Node();
	node->data =*emp;
	node->nextptr = head;
	return node;
}
Node* FindPrev(Node *head)
{
	int key;
	cout << "\nEnter the Previous ID: ";
	cin >> key;
	cout << endl;
	for (Node *i = head; i != NULL;i = i->nextptr)
	{
		if (i->data.ID == key)
		{
			return i;
		}
	}
}

Node* FindNext(Node *head)
{
	int key;
	cout << "\nEnter the Next ID: ";
	cin >> key;
	cout << endl;
	for (Node *i = head; i != NULL;i = i->nextptr)
	{
		if (i->data.ID == key)
		{
			if (i->nextptr != NULL)
			{
				i = i->nextptr;
				return i;
			}
		}
	}
}
Node * CreateNode(Node* previous, Employee *emp)
{
	Node * node = new Node();
	node->data = *emp;
	node->nextptr = previous->nextptr;
	previous->nextptr = node;
	return node;


}
Node * CreateInBetween(Node * Previous, Node *After, Employee *emp)
{
	Node *node = new Node();
	node->data = *emp;
	node->nextptr = After;
	Previous->nextptr = node;
	return node;
}
struct Writer
{

	const char * file_name;
	Node *head;
	Writer() {}
	Writer(const char* _file, Node *_head) { file_name = _file;head = _head; }
	void operator () ()
	{
		ofstream writer(file_name, ios::out);
		while (head)
		{
			writer << head->data.ID << '|';
			writer << head->data.FN << '|';
			writer << head->data.LN << '|';
			head = head->nextptr;
		}
		writer.close();
		cout << "\nWrite was ok!!!\n";

	}
};
struct Reader
{

	string path;
	Node *head;
	Employee *r;
	Reader() {}
	Reader(string _path, Node *_head) { path = _path; head = _head; }
	void operator () ()
	{

		ifstream reader(path, ios::in | ios::binary);
		if (reader.good())
		{

			while (reader.peek() != EOF)
			{
				r = new Employee();
				if (reader.read(reinterpret_cast<char*>(r), sizeof(Employee)).good())
				{
					head->data = *r;
				}
				else exit;


			}
		}
		reader.close();

	}

};
void Search(Node *head,int key)
{
	
	cout << "\nEnter the ID: ";
	cin >> key;
	cout << endl;
	for (Node *i = head; i != NULL;i = i->nextptr)
	{
		if (i->data.ID == key)
		{
		
			cout << i->data;

			if (i->nextptr != NULL)
			{
				i = i->nextptr;

				cout << "\nNext Employee : " << i->data;
				cout << endl;
			}
		}
	}
}
void Search(Node *head,string key)
{
	cout << "\nEnter the SSN: ";
	cin >> key;
	cout << endl;
	for (Node *i = head; i != NULL;i = i->nextptr)
	{
		if (i->data.SSN == key)
		{

			cout << i->data;

			if (i->nextptr != NULL)
			{
				i = i->nextptr;

				cout << "\nNext Employee : " << i->data;
				cout << endl;
			}
		}
	}
}
bool operator < (Employee &x, Employee &y)
{
	return x.ID <= y.ID;

}
bool compare(Employee &x, Employee &y)
{
	return x < y;
}
void swap(Employee &x, Employee &y)
{
	Employee temp;
	temp = x;
	x = y;
	y = temp;

}
void sort(Node *head)
{
	for (Node *i = head;i != NULL;i = i->nextptr)
	{
		for (Node *j = head; j != i; j = j->nextptr)
		{
			if (compare(i->data, j->data))
			{
				swap(i->data, j->data);
			}
		}

	}
}
void sortByFN(Node *head)
{
	for (Node *i = head;i != NULL;i = i->nextptr)
	{
		for (Node *j = head; j != i; j = j->nextptr)
		{
			if (i->data.FN>j->data.FN)
			{
				swap(i->data, j->data);
			}
		}

	}
}
void FindToDelete(Node *head)
{

	int key;
	cout << "\nEnter the  ID: ";
	cin >> key;
	cout << endl;
	for (Node *i = head; i != NULL;i = i->nextptr)
	{
		for (Node *j = i; j != i; j = j->nextptr)
		{
			if (j->data.ID == key)
			{
			
				i->nextptr = j->nextptr;

			}
		}
	}
}
void Display(Node *head)
{
	for (Node *ind = head; ind != NULL; ind = ind->nextptr)
	{
		cout << ind->data;
	}
}
int menu()
{
	int choice;
	cout << "\n\t1. Add an employee." << endl;
	cout << "\n\t2. Remove an employee." << endl;
	cout << "\n\t3. Search for an employee by identification number or by social security number." << endl;
	cout << "\n\t4. Display all employees." << endl;
	cout << "\n\t5. Sort the employees by social security number or by full name." << endl;
	cout << "\n\t6. Write the employee data to the file." << endl;
	cout << "\n\t7. Read the employee data from the file." << endl;
	cout << "\n\t\tEnter your choice:";
	cin >> choice;
	return choice;
}
int Addmenu()
{
	int opt;
	cout << "1.Add Head" << endl;
	cout << "2.Add Tail" << endl;
	cout << "3.Add in Between" << endl;
	cout << "Enter your choice:";
	cin >> opt;
	return opt;

}
int SearchMenu()
{

	int opt;
	cout << "1.ID" << endl;
	cout << "2.SSN" << endl;
	cout << "Enter your choice:";
	cin >> opt;
	return opt;

}
int SortMenu()
{

	int opt;
	cout << "1.ID" << endl;
	cout << "2.FN" << endl;
	cout << "Enter your choice:";
	cin >> opt;
	return opt;

}
int main()
{
	Employee *Emp = new Employee();
	Writer myWriter;
	Reader myReader;

	Node *Head = NULL;
	Node *head = NULL;

	Node *headNode = new Node();
	Node *node;
	Node *NodeInBetween;
	int kID = 0;
	string kSSN;
	int opt, Sortopt, sopt;

	do
	{
		system("cls");
		int choice = menu();

		switch (choice)
		{
		case 1: system("cls");
			opt = Addmenu();
			switch (opt)
			{
			case 1:system("cls");
				cin >> Emp;
				headNode = HeadNode(Head, Emp);
				Head = headNode;
				

				cout << "Created";
				system("pause>>null");

				break;
			case 2:system("cls");
				if (Head != NULL)
				{	
					cin >> Emp;
					node = FindPrev(Head);
					CreateNode(node, Emp);
					cout << "Created";
				}
				else
				{
					cout << "Make the first employee as a head first" << endl;
				}
				system("pause>>null");

				break;
			case 3:	system("cls");
				if (Head != NULL)
				{
					if (Head->nextptr != NULL)
					{
						cin >> Emp;
						NodeInBetween = CreateInBetween(FindPrev(Head), FindNext(Head), Emp);
						cout << "Created";
					}
					else
					{
						cout << "Must have minimum 2 students";
					}
				}
				else
				{
					cout << "Make the first employee as a head first" << endl;
				}
				break;
				break;
			}
			break;
		case 2:
			system("cls");
			if (Head != NULL)
			{
				FindToDelete(Head);
			}
			else
			{
				cout << "Make the first employee as a head first" << endl;
			}
			break;
		case 3:

			system("cls");
			sopt = SearchMenu();
			switch (sopt)
			{
			case 1: 
				system("cls");
				Search(Head,kID);
				system("pause>>null");
				break;
			case 2: 
				system("cls");
				Search(Head,kSSN);
				system("pause>>null");
				break;
			}
			system("pause>>null");
			break;
		case 4:system("cls");
			Display(Head);
			system("pause>>null");

			break;
		case 5: system("cls");
			Sortopt = SortMenu();
			switch (Sortopt)
			{
			case 1:
				system("cls");
				sort(Head);
				Display(Head);
				system("pause>>null");
			case 2:
				system("cls");
				sortByFN(Head);
				Display(Head);

				system("pause>>null");
				break;
		
				break;

			}
			break;
		case 6:system("cls");
			myWriter.head = Head;
			myWriter();


			system("pause>>null");
		case 7:
			system("cls");
			myReader.head = head;
		

			myReader();
			Head = head;
			Display(Head);
			system("pause>>null");
		}
	} while (true);

	system("pause>>null");
	return 0;
}

